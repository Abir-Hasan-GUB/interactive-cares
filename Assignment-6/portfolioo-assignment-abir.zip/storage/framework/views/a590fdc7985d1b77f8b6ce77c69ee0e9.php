<!DOCTYPE html>
<html lang="en" data-bs-theme="light">

<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
    <meta name="description" content=""/>
    <meta name="author" content=""/>
    <title>MR-X</title>
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('asset/favicon.ico')); ?>"/>
    <link href="<?php echo e(asset('https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css')); ?>"
          rel="stylesheet"/>
    <link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet"/>
</head>

<body class="d-flex flex-column h-100">

<?php echo $__env->make('components.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section id="content-div" class="">
    <?php echo $__env->yieldContent('content'); ?>
</section>

<?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\Users\Abir Hasan\Desktop\PHP-ShamimBhai\Assignment-6\portfolio\resources\views/app.blade.php ENDPATH**/ ?>