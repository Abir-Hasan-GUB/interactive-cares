<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('components.projects', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('components.call-to-action', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abir Hasan\Desktop\PHP-ShamimBhai\Assignment-6\portfolio\resources\views/pages/projects.blade.php ENDPATH**/ ?>