<div class="container">

    <div class="singleProject">
        <div class="text-start mb-5 pt-5">
            <h1 class="display-5 fw-bolder mb-0"><span class="text-gradient d-inline"><?php echo e($project['name']); ?></span></h1>
        </div>

        <div class="author d-flex align-items-center justify-content-between pb-4">
            <div class="authorInfo">
                <p class="authorName p-0 m-0"> <b>Author:</b> <?php echo e($project['author']); ?></p>
                <p class="authorName p-0 m-0"> <b>Company:</b> <?php echo e($project['company']); ?></p>
            </div>
            <div class="timeFrame">
                <p class="p-0 m-0"> <b>Updated At:</b> <span><?php echo e($project['updated_at']); ?></span> </p>
                <p class="p-0 m-0"> <b>Publish At:</b> <span><?php echo e($project['publish_at']); ?></span> </p>
            </div>
        </div>

        <div class="projectBanner">
            <img src="<?php echo e($project['banner']); ?>" alt="" class="img-fluid w-100" style="max-height: 600px;">
        </div>

        <div class="details pb-5">
            <?php echo $project['description']; ?>

        </div>
    </div>

</div>
<?php /**PATH C:\Users\Abir Hasan\Desktop\PHP-ShamimBhai\Assignment-6\portfolio\resources\views/projects/project-details.blade.php ENDPATH**/ ?>