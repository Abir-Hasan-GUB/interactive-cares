  <!-- Footer-->
  <footer class="bg-secondary  py-4 mt-auto">
    <div class="container px-5">
        <div class="row align-items-center justify-content-between flex-column flex-sm-row text-light">
            <div class="col-auto"><div class="small m-0">Copyright &copy; Your Website 2023</div></div>
            <div class="col-auto">
                <a class="small text-light" href="#!">Privacy</a>
                <span class="mx-1">&middot;</span>
                <a class="small text-light" href="#!">Terms</a>
                <span class="mx-1">&middot;</span>
                <a class="small text-light" href="<?php echo e(route('contact')); ?>">Contact</a>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\Users\Abir Hasan\Desktop\PHP-ShamimBhai\Assignment-6\portfolio\resources\views/components/footer.blade.php ENDPATH**/ ?>