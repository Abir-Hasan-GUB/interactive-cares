<!-- Call to action section-->
<section class="py-5 bg-gradient-primary-to-secondary text-white">
    <div class="container px-5 my-5">
        <div class="text-center">
            <h2 class="display-4 fw-bolder mb-4">Let's build something together</h2>
            <a class="btn btn-outline-light btn-lg px-5 py-3 fs-6 fw-bolder" href="<?php echo e(route('contact')); ?>">Contact me</a>
        </div>
    </div>
</section>
<?php /**PATH C:\Users\Abir Hasan\Desktop\PHP-ShamimBhai\Assignment-6\portfolio\resources\views/components/call-to-action.blade.php ENDPATH**/ ?>