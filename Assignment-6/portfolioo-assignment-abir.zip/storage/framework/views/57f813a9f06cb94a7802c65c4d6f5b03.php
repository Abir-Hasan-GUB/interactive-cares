<!-- Projects Section-->
<section class="py-5">
    <div class="container px-5 mb-5">
        <div class="text-center mb-5">
            <h1 class="display-5 fw-bolder mb-0"><span class="text-gradient d-inline">Projects</span></h1>
        </div>
        <div class="row justify-content-center row-cols-md-3 g-4 row-cols-1">
            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col">
                    <a href="<?php echo e(route('projects.show', ['id' => $project['id']])); ?>" style="text-decoration: none;">
                        <div class="card overflow-hidden shadow rounded-4 border-0 h-100">
                            <div class="card-body p-0">
                                <div class="">
                                    <div class="p-3">
                                        <img class="img-fluid w-100" src="<?php echo e(url($project['banner'])); ?>" alt="..."
                                            style="height: 220px;" />
                                        <h5 class="fw-bolder pt-3">
                                            <?php echo e($project['name']); ?>

                                        </h5>
                                        <?php echo $project['short_details']; ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php /**PATH C:\Users\Abir Hasan\Desktop\PHP-ShamimBhai\Assignment-6\portfolio\resources\views/components/projects.blade.php ENDPATH**/ ?>