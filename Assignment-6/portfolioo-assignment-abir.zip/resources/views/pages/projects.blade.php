@extends('app')

@section('content')
    @include('components.projects')
    @include('components.call-to-action')
@endsection
