@extends('app')

@section('content')
    @include('components.header')
    @include('components.about')
@endsection
