@extends('app')

@section('content')
    @include('components.resume-contents')
@endsection
