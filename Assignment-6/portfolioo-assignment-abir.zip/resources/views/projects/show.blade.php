@extends('app')

@section('content')
    @include('projects.project-details')
@endsection
